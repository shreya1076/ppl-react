import React from "react";
import ReactDOM from "react-dom";
import "./index.css";
import registerServiceWorker from "./registerServiceWorker";
import { Register } from "./register";
import { Login } from "./login";

ReactDOM.render(<Register />, document.getElementById("root"));
registerServiceWorker();
