var express = require("express");
var app = express();
var cors = require("cors");
var router = require("./router");
var mongoose = require("mongoose");
app.use(cors()); // kisi bhi origin sa request aaya like 3000,5000

const bodyParser = require("body-parser");

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

mongoose.connect("mongodb://localhost:27017/ppl"); //server ko database se connect

app.use("/", router);

// Routes

app.listen(4000, () => {
  console.log("Listening on port no 4000");
});
