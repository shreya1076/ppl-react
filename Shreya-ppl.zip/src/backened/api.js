var userdb = require("./schema");
module.exports = {
  createnewuser: function(data) {
    return new Promise((resolve, reject) => {
      console.log("api", data);
      userdb.create(data, (err, result) => {
        // it has user collection mongooose model
        if (err) {
          reject(err);
        } else {
          resolve(result);
        }
      });
    });
  },
  finduser: function(data) {
    return new Promise((resolve, reject) => {
      userdb.find(data, (error, result) => {
        if (error) {
          reject(error);
        } else {
          console.log("result", result);
          resolve(result);
        }
      });
    });
  }
  //   updatename: function(data) {
  //     // return new Promise((resolve, reject) => {
  //     console.log("<<<<<<data", data);
  //     return userdb.update(
  //       { name: data.nameToBeUpdated },
  //       { $set: { lname: data.updateName } },
  //       { multi: treturnrue },
  //       (error, result) => {
  //         if (error) {
  //           console.log(">>>>>>> Error : ", error);
  //           return error;
  //           // reject(error);
  //         } else {
  //           console.log(">>>>>>> Result : ", result);
  //           return result;
  //           // resolve(result);
  //         }
  //       }
  //     );
  //     // });
  //   }
};
