var express = require("express");
var router = express.Router();
var userapi = require("./api");
const nodemailer = require("nodemailer");

nodemailer.createTestAccount((err, account) => {
  let transporter = nodemailer.createTransport({
    //transporter is going to be an object to send mails
    service: "Gmail",
    auth: {
      user: "shreya.sehgal@daffodilsw.com",
      pass: "shreya35"
    }
  });

  let mailOptions = {
    from: "shreya.sehgal@daffodilsw.com",
    to: "shreyasehgalbhatia0305@gmail.com",
    subject: "Hello ✔",
    text: "Hello world",
    html: "<b>Hello world?<a></a></b>"
  };
  transporter.sendMail(mailOptions, (error, info) => {
    //sendMail(data,callback)
    if (error) {
      return console.log(error);
    }
    console.log("Message sent: %s", info);
    console.log("Preview URL: %s", nodemailer.getTestMessageUrl(info));
  });
});
router.post("/register", async (req, res) => {
  console.log("router on backend", req.body);
  try {
    var data = {};
    data.username = req.body.Username;
    data.password = req.body.Password;
    data.email = req.body.Email;
    data.firstName = req.body.FirstName;
    data.lastName = req.body.LastName;

    let whetherEmailExist = await userapi.finduser({ email: data.email });
    console.log("<<<<<<<<whetherEmailExist", whetherEmailExist);
    if (whetherEmailExist.length === 0) {
      let resultfromapi = await userapi.createnewuser(data);
      console.log("resultfromapi", resultfromapi);

      res.send(resultfromapi);
    } else {
      console.log("<<<<else");
      res.send({ result: "This email id already exists" });
    }
  } catch (err) {
    console.log(" the error is err", err);
    res.send(err);
  }
});
router.post("/login", async (req, res) => {
  console.log("<<<<login data from client", req.body);
  let data = {};
  data.email = req.body.emailId;
  data.password = req.body.password;
  console.log("<<<<<<<data", data);
  let checkEmailandPasswordexist = await userapi.finduser(data, data);
  console.log("<<<<<<<checkEmailandPasswordexist", checkEmailandPasswordexist);
  if (checkEmailandPasswordexist.length > 0) {
    res.send(checkEmailandPasswordexist);
  } else {
    res.send({ error: "no user exists with this email and password" });
  }
});

module.exports = router;
