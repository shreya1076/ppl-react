import React, { Component } from "react";
class Form extends Component {
  constructor(props) {
    super(props);
    this.state = {
      fname: "Jack",
      lname: "Saxena",
      qual: "MBA",
      hobbies: "resting",
      age: 25,
      school: "Air Force School",
      nameUpdate: "tomy"
    };
  }
  buttonClick = () => {
    console.log("<<<<<<<<<<<<<clicked");
    // this.setState({ name: "Jones" });
    let options = {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      },
      body: JSON.stringify(this.state)
    };
    console.log("options", options);
    fetch("http://localhost:4000/form", options)
      .then((response) => response.json())
      .then((json) => {
        console.log("<<<<<data", json);
      })
      .catch((err) => {
        console.log("errr");
      });
  };
  func2 = (e) => {
    console.log(">>>>>>> Name :: ", e.target.name);
    const name = e.target.name;
    this.setState({ [name]: e.target.value });
  };
  submitClick = () => {
    console.log("<<<<<<<<<submit button");
    let data = {
      lname: this.state.hobbies
    };
    console.log("data", data);
    let options = {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      },
      body: JSON.stringify(data)
    };
    console.log("<<<<<<<<options::::", options);
    fetch("http://localhost:4000/submit", options)
      .then((response) => response.json())
      .then((json) => {
        console.log("<<<<<data from submit button", json);
      })
      .catch((err) => {
        console.log("errr on click of submit button");
      });
  };
  updateButton = () => {
    console.log("<<<<<<updated");
    let data = {
      updateName: this.state.school,
      nameToBeUpdated: this.state.nameUpdate
    };
    let options = {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      },
      body: JSON.stringify(data)
    };
    fetch("http://localhost:4000/update", options)
      .then((response) => response.json())
      .then((json) => {
        console.log("data from update button", json);
      })
      .catch((err) => {
        console.log("err on click of delete button");
      });
  };

  render() {
    return (
      <div>
        Name: <input type="text" name="fname" onChange={this.func2} />
        Lname: <input type="text" name="lname" onChange={this.func2} />
        Qualification:  <input tyype="text" name="qual" onChange={this.func2} />
        Username : <input type="text" name="hobbies" onChange={this.func2} />
        <button type="button" onClick={this.submitClick}>
          Submit
        </button>
        Enter Username to update:{" "}
        <input type="text" name="nameUpdate" onChange={this.func2} />
        <br />
        <br />
        <br />
        Update: <input type="text" name="school" onChange={this.func2} />
        <br />
        <br />
        <button type="button" onClick={this.updateButton}>
          Update
        </button>
        {/* </form> */}
      </div>
    );
  }
}
export default Form;
